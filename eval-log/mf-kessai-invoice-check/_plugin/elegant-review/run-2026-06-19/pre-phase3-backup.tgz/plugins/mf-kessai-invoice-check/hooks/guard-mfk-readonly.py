#!/usr/bin/env python3
"""PreToolUse hook: MF掛け払い APIへの変更系リクエストを遮断し参照専用を機械保証する。

Bash/curl/python で api.mfkessai.co.jp へ POST/PUT/PATCH/DELETE しようとしたら exit 2 で拒否。
GET(参照)は許可。発行漏れチェックは参照専用という boundary を指示でなく仕組みで担保する。
Notion(api.notion.com)への書き込みは対象外(MFは読むだけ・Notionは書く の一方向)。
"""
import json
import re
import sys

_HOST = "mfkessai.co.jp"
_MUTATION_PATTERNS = [
    r"-x\s+(post|put|patch|delete)\b",
    r"--request\s+(post|put|patch|delete)\b",
    r"\.(post|put|patch|delete)\s*\(",
    r"method\s*[=:]\s*['\"]?(post|put|patch|delete)",
    # subprocess の list 形式 (例: ["curl","-X","POST"]) を JSON 文字列で検出
    r'"-x",\s*"(post|put|patch|delete)"',
    r'"--request",\s*"(post|put|patch|delete)"',
]


def main():
    try:
        payload = json.load(sys.stdin)
    except Exception:
        return 0
    tool = payload.get("tool_name", "")
    ti = payload.get("tool_input", {}) or {}
    text = ti.get("command", "") if tool == "Bash" else json.dumps(ti, ensure_ascii=False)
    if _HOST not in text:
        return 0
    lowered = text.lower()
    if any(re.search(p, lowered) for p in _MUTATION_PATTERNS):
        sys.stderr.write(
            "[guard-mfk-readonly] MF掛け払いAPIへの変更系(POST/PUT/PATCH/DELETE)は禁止です。"
            "発行漏れチェックは参照専用(GET)です。請求書の発行・更新はMF管理画面で行ってください。\n"
        )
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
