#!/usr/bin/env python3
"""発行漏れチェック結果を Notion DB に冪等 upsert する sink。

キー: customer_id × 対象年月(period_ym)。毎月実行で重複行を作らず既存行を更新する。
**事実列のみ** を書き込み、管理列(請求要否/対応状況/チェック済/備考)には触れない
(人の運用記入を自動実行が上書きしないため)。
Notion トークンは Keychain (notion-api-key.xl-skills / xl-skills) から取得。
"""
import json
import os
import subprocess
import urllib.error
import urllib.request

NOTION_API = "https://api.notion.com/v1"
NOTION_VERSION = "2022-06-28"


def _notion_token():
    service = os.environ.get("NOTION_KEYCHAIN_SERVICE", "notion-api-key.xl-skills")
    account = os.environ.get("NOTION_KEYCHAIN_ACCOUNT", "xl-skills")
    env = os.environ.get("NOTION_API_KEY")
    if env and env.strip():
        return env.strip()
    res = subprocess.run(
        ["/usr/bin/security", "find-generic-password", "-s", service, "-a", account, "-w"],
        capture_output=True, text=True,
    )
    if res.returncode != 0 or not res.stdout.strip():
        raise RuntimeError(f"Notion token lookup failed (service={service}, account={account})")
    return res.stdout.strip()


def _req(method, path, token, body=None):
    url = NOTION_API + path
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Authorization", f"Bearer {token}")
    req.add_header("Notion-Version", NOTION_VERSION)
    req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"Notion {method} {path}: HTTP {e.code} {e.read().decode('utf-8', 'replace')}")


def _find_page(database_id, customer_id, period_ym, token):
    """customer_id × period_ym で既存ページを検索。あれば page_id を返す。"""
    body = {"filter": {"and": [
        {"property": "顧客ID", "rich_text": {"equals": customer_id}},
        {"property": "対象年月", "rich_text": {"equals": period_ym}},
    ]}}
    res = _req("POST", f"/databases/{database_id}/query", token, body)
    items = res.get("results", [])
    if len(items) > 1:  # 冪等キーが壊れている。暗黙に先頭採用せず運用者に気づかせる
        raise RuntimeError(
            f"重複行検出: 顧客ID={customer_id} 対象年月={period_ym} が {len(items)}件存在。"
            "手動で重複を解消してから再実行してください (customer_id×対象年月 は一意のはず)。")
    return items[0]["id"] if items else None


def _props(row):
    """発行漏れ結果1件を Notion プロパティ形式に変換 (事実列のみ)。"""
    def rt(v):
        return {"rich_text": [{"text": {"content": str(v if v is not None else "")}}]}

    def num(v):
        return {"number": (int(v) if v is not None else None)}

    props = {
        "取引先企業名": {"title": [{"text": {"content": row.get("company_name", "")}}]},
        "顧客ID": rt(row.get("customer_id")),
        "対象年月": rt(row.get("period_ym")),
        "判定": {"select": {"name": row.get("verdict", "発行漏れ候補")}},
        "商品名": rt(row.get("product_name")),
        "前月金額": num(row.get("prev_amount")),
        "今月金額": num(row.get("curr_amount")),
    }
    if row.get("issue_date"):
        props["発行日"] = {"date": {"start": row["issue_date"]}}
    if row.get("updated_at"):
        props["更新日"] = {"date": {"start": row["updated_at"]}}
    return props


def upsert(database_id, rows, token=None):
    """rows を customer_id×period_ym キーで冪等 upsert。作成/更新件数を返す。

    rows: [{customer_id, period_ym, company_name, verdict, product_name,
            prev_amount, curr_amount, issue_date?, updated_at?}, ...]
    """
    token = token or _notion_token()
    created = updated = 0
    for row in rows:
        page_id = _find_page(database_id, row["customer_id"], row["period_ym"], token)
        if page_id:
            _req("PATCH", f"/pages/{page_id}", token, {"properties": _props(row)})
            updated += 1
        else:
            _req("POST", "/pages", token,
                 {"parent": {"database_id": database_id}, "properties": _props(row)})
            created += 1
    return {"created": created, "updated": updated}
