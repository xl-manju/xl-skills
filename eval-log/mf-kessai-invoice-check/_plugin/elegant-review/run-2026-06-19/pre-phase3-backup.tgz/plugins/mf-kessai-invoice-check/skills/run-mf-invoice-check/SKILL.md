---
name: run-mf-invoice-check
description: 前月と今月の請求書発行漏れをチェックしたいとき、月次で請求発行状況を確認したいときに使う。
disable-model-invocation: true
user-invocable: true
argument-hint: "[--month YYYY-MM]"
arguments: [month]
allowed-tools:
  - Read
  - Write
  - Bash(python3 *)
  - Task
kind: run
prefix: run
effect: external-mutation
owner: team-platform
since: 2026-06-19
version: 0.1.0
source: doc/ClaudeCodeスキルの設計書/
source-tier: internal
last-audited: 2026-06-19
audit-trigger: quarterly
responsibility_refs:
  - prompts/R1-collect.md
  - prompts/R2-diff.md
  - prompts/R3-verify.md
  - prompts/R4-sink.md
schema_refs:
  - schemas/invoice-gap-result.schema.json
manifest: workflow-manifest.json
---

# run-mf-invoice-check

## Purpose & Output Contract

前月発行・今月未発行の取引先（発行漏れ候補）を MF掛け払い API から差集合で洗い出し、商品名・前月/今月金額・取引先企業名を突合して Notion DB に冪等 upsert し、画面にも要確認リストを表示する。

**入力**: `month`（任意。既定は実行日の月。前月は自動算出）
**出力**: 発行漏れ候補が Notion DB に反映 + 画面に要確認リスト。
**完了条件**: collect→verify(subagent)→sink が完了し、確定候補が Notion に upsert された状態。

## End-to-End Flow

```
[1 collect] check_invoice_gaps.py --collect → eval-log/mfk-gap-candidates.json + 画面サマリ
[2 diff]    lib/mfk_invoice_diff.detect_gaps (collect内, 純関数・pytest済)
[3 verify]  subagent mfk-gap-verifier (context:fork) で誤検出排除
[4 sink]    check_invoice_gaps.py --sink → Notion 冪等upsert
            ↑ MF APIは全GET / POST等は PreToolUse hook(guard-mfk-readonly.py)で遮断
```

詳細は `workflow-manifest.json`、責務は `prompts/R1-R4`。

## ゴールシーク実行

### ゴール (Goal)
前月発行−今月発行の差集合（発行漏れ候補）が商品名/金額/取引先企業名つきで Notion DB に冪等 upsert され、独立 context の subagent で誤検出を排除した要確認リストが画面に提示された状態。

### 目的・背景 (Why)
発行漏れの早期発見。チェック漏れは取引先との信頼低下に直結するため、月次で機械的に差集合を洗い出す。契約終了等の除外は API で判別できないため人が請求要否列で管理し、機械では消さない。誤検出を防ぐため候補は独立 context で二段確認する。

### 責務サマリと完了条件の正本

各責務の**完了条件の詳細は `prompts/Rn` の L5.3 完了チェックリストを正本 (SSOT)** とする (片側更新ドリフトを避けるため SKILL 側で再定義しない)。本節は俯瞰用の責務サマリのみ示す。

- **R1 collect** (`prompts/R1-collect.md`): 前月・今月の `/billings/qualified` を全ページ取得する。
- **R2 diff** (`prompts/R2-diff.md`): 取得集合を `発行漏れ候補/継続発行/今月新規` に差集合分類し金額変動を検出する。
- **R3 verify** (`prompts/R3-verify.md`): subagent `mfk-gap-verifier` が独立 context で誤検出を排除する。
- **R4 sink** (`prompts/R4-sink.md`): customer_id×対象年月キーで Notion DB に冪等 upsert する (重複行を作らず管理列に触れない)。

横断不変条件 (各 Rn の L1/L4 が担保): 契約終了等の除外は機械で消さず請求要否列で人が管理。MF API への POST/PATCH/DELETE は hook で遮断され参照専用が保証される。

### ゴールシークループ
1. `--collect` で現状取得→差集合→突合し候補JSONを得る（`R1`/`R2`）。
2. subagent で二段確認し誤検出を排除（`R3`）。確定リストを得る。
3. `--sink` で Notion へ冪等 upsert（`R4`）。
4. 全 checklist 充足で完了。`database_id` 未設定なら db-setup へ差し戻す。

## Key Rules

1. **参照専用（機械保証）**: MF APIへの変更系は `hooks/guard-mfk-readonly.py`（PreToolUse）で遮断。指示でなく仕組みで担保。
2. **一覧は qualified**: インボイスモードで `/billings` は空。`/billings/qualified` を使う。
3. **冪等 upsert**: customer_id×対象年月キー。事実列のみ書き、管理列は触らない。
4. **二段確認必須**: 候補は subagent(context:fork) でレビューしてから投入（Sycophancy/誤検出防止）。
5. **除外は人**: 契約終了等の請求不要判断は機械で消さず Notion 請求要否列へ。

## Gotchas

1. `database_id` 未設定なら `run-mf-invoice-db-setup` を先に実行。
2. MF APIキーと Notion トークンは別 Keychain entry。
3. `updated_at` は無いので更新日は `created_at` で代替。
4. 月をまたぐ発行（5月取引→6月発行）があるため判定軸は必ず `issue_date`。

## Additional Resources

- `workflow-manifest.json` — collect/diff/verify/sink の Step 定義 + hook guard
- `scripts/check_invoice_gaps.py` — collect/sink 実行スクリプト
- `prompts/R1-collect.md`〜`R4-sink.md` — 責務プロンプト
- `../ref-mf-kessai-api/` — API仕様・判定アルゴリズム正本
- `../../lib/` — mfk_api / mfk_keychain / mfk_invoice_diff / notion_invoice_sink
- `../../hooks/guard-mfk-readonly.py` — 参照専用ガード
- `../../agents/mfk-gap-verifier.md` — 二段確認 subagent
