---
name: run-mf-invoice-db-setup
description: 発行漏れチェック用のNotion DBを初回構築したいとき、DBのプロパティ設計を作り直したいときに使う。
disable-model-invocation: true
user-invocable: true
argument-hint: "[--parent-page-id <id>]"
arguments: [parent_page_id]
allowed-tools:
  - Read
  - Write
  - Bash(python3 *)
kind: run
prefix: run
effect: external-mutation
owner: team-platform
since: 2026-06-19
version: 0.1.0
source: doc/ClaudeCodeスキルの設計書/
source-tier: internal
last-audited: 2026-06-19
audit-trigger: quarterly
responsibility_refs:
  - prompts/R1-build-db.md
  - prompts/R2-verify-schema.md
schema_refs:
  - schemas/notion-db-schema.json
---

# run-mf-invoice-db-setup

## Purpose & Output Contract

発行漏れチェック (`run-mf-invoice-check`) の出力先となる Notion DB のスキーマを用意する。事実列 (API由来) と管理列 (人の運用) を分離した設計を `schemas/notion-db-schema.json` 正本から物質化する。冪等に動く 2 モード:

- **既存DBへ適用** (既定): `database_id` が設定済み (配布既定 `mf-kessai-config.default.json` の『請求書チェック_DB』) の場合、その DB に不足プロパティを追加しタイトル列を `取引先企業名` にリネームする。既存データ・管理列記入は壊さない。
- **新規作成**: `database_id` が空で `parent_page_id` がある場合、親ページ配下に新規 DB を作成し `database_id` をローカル `.mf-kessai-config.json` に記録する。

**入力**: `parent_page_id` (新規作成モードのみ。既定では不要)
**出力**: Notion DB が schema 通りに整い、`verify_db_schema.py` が全プロパティ PASS を返す。
**完了条件**: 対象 DB のプロパティが schema と一致 + `verify_db_schema.py` が PASS。

## ゴールシーク実行

### ゴール (Goal)
発行漏れチェック結果を投入できる Notion DB が、事実列＋管理列の設計通りに作成され、`database_id` が config に記録され、検証スクリプトが PASS した状態。

### 目的・背景 (Why)
月次チェックの出力先を初回に用意する。API由来の事実列と人が運用する管理列を分離した設計を確立し、後段の冪等 upsert が安定して書き込める土台を作る。スキーマ drift を検知するため作成後に機械検証する。

### 完了チェックリスト (Checklist)
- [ ] `notion.parent_page_id` が設定されている (空なら停止しユーザーへ共有依頼)
- [ ] `build_notion_db.py` が DB を作成し `database_id` を返す (既存があれば冪等スキップ)
- [ ] 事実列 (取引先企業名/顧客ID/対象年月/判定/商品名/前月金額/今月金額/発行日/更新日) が存在
- [ ] 管理列 (請求要否/対応状況/チェック済/備考) が存在
- [ ] `database_id` が `.mf-kessai-config.json` に記録される
- [ ] `verify_db_schema.py` が全プロパティ PASS

### ゴールシークループ
1. config の `parent_page_id`/`database_id` を読み現状評価 (`R1`)。
2. 未作成なら `build_notion_db.py` を実行、既存なら冪等スキップ。
3. `verify_db_schema.py` で検証 (`R2`)。FAIL なら欠落を提示し再実行/手動追補へ差し戻す。
4. 全 checklist 充足で完了。

## Key Rules

1. **parent_page_id 必須**: 空なら停止。Notion 共有 (インテグレーション接続) が前提。
2. **status型は使わない**: 「対応状況」は select で表現 (Notion API は status 新規作成不可)。
3. **管理列を破壊しない**: 再実行・再構築でも人が記入した管理列・既存データを壊さない (冪等)。
4. **schema 正本一元**: プロパティ定義は `schemas/notion-db-schema.json` のみ。スクリプトはそれを読む。

## Gotchas

1. Notion トークンと MF APIキーは**別 Keychain entry**。本スキルは Notion トークン (`notion-api-key.xl-skills`) を使う。
2. `database_id` が既に config にある状態で再実行しても新規作成しない (重複DB防止)。
3. `number` プロパティは `format: yen` で円表示。

## Additional Resources

- `schemas/notion-db-schema.json` — DBプロパティ正本 (事実列/管理列/upsert_key)
- `scripts/build_notion_db.py` — DB作成 + database_id 記録
- `scripts/verify_db_schema.py` — プロパティ存在検証 (drift検知)
- `prompts/R1-build-db.md` / `prompts/R2-verify-schema.md` — 責務プロンプト
- `../ref-mf-kessai-api/` — Notion へ入れるデータの取得元仕様
