#!/usr/bin/env python3
"""月次発行漏れチェック実行スクリプト。

  --collect : 前月/今月の発行済み請求を取得→差集合→商品名/金額/企業名突合→候補JSON出力
  --sink    : 検証済み候補JSONを Notion DB に冪等 upsert

月は --month YYYY-MM (既定: 実行日の月)。前月は自動算出。
全て GET (参照専用)。MF APIへの POST/PATCH/DELETE は PreToolUse hook で遮断される。
"""
import argparse
import calendar
import datetime
import json
import os
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
_PLUGIN_ROOT = os.path.abspath(os.path.join(_HERE, "..", "..", ".."))
_REPO_ROOT = os.path.abspath(os.path.join(_PLUGIN_ROOT, "..", ".."))
sys.path.insert(0, os.path.join(_PLUGIN_ROOT, "lib"))
from mfk_api import get, iter_all, load_config  # noqa: E402
from mfk_invoice_diff import amount_changed, detect_gaps  # noqa: E402
import notion_invoice_sink  # noqa: E402

DEFAULT_CANDIDATES = os.path.join(_REPO_ROOT, "eval-log", "mfk-gap-candidates.json")


def month_range(ym):
    y, m = map(int, ym.split("-"))
    last = calendar.monthrange(y, m)[1]
    return f"{y:04d}-{m:02d}-01", f"{y:04d}-{m:02d}-{last:02d}"


def prev_month(ym):
    y, m = map(int, ym.split("-"))
    m -= 1
    if m == 0:
        y -= 1
        m = 12
    return f"{y:04d}-{m:02d}"


def fetch_issued(ym):
    first, last = month_range(ym)
    return list(iter_all("/billings/qualified", {
        "issue_date_from": first, "issue_date_to": last, "status": "invoice_issued",
    }))


def by_customer(billings):
    out = {}
    for b in billings:
        out.setdefault(b["customer_id"], b)
    return out


def resolve_names(customer_ids):
    names = {}
    ids = list(customer_ids)
    for i in range(0, len(ids), 200):
        chunk = ids[i:i + 200]
        data = get("/customers", {"ids": chunk, "limit": 200})
        for c in data.get("items", []):
            names[c["id"]] = c.get("name", "")
    if ids and not names:  # 全件解決失敗 = パラメータ形式の疑い。空欄で黙って進めない
        sys.stderr.write(
            f"[check] 警告: 顧客ID {len(ids)}件に対し企業名が1件も解決できませんでした。"
            "/customers?ids= の形式を実APIで確認してください (このままだと企業名が空欄になります)。\n")
    return names


def detail_of(billing_id):
    """billing の商品名(先頭3明細)と更新日(transaction.created_at の最新)を返す。"""
    if not billing_id:
        return {"product_name": "", "updated_at": None}
    data = get("/transactions", {"billing_id": billing_id, "limit": 5})
    descs, updated = [], None
    for t in data.get("items", []):
        ca = t.get("created_at")
        if ca and (updated is None or ca > updated):
            updated = ca
        for d in t.get("transaction_details", []):
            if d.get("description"):
                descs.append(d["description"])
    return {"product_name": " / ".join(descs[:3]), "updated_at": updated}


def collect(ym):
    prev_ym = prev_month(ym)
    prev_b = fetch_issued(prev_ym)
    curr_b = fetch_issued(ym)
    res = detect_gaps(prev_b, curr_b)
    prev_by, curr_by = by_customer(prev_b), by_customer(curr_b)
    changed = set(amount_changed(res["continuing"], res["prev_amount"], res["curr_amount"]))
    targets = set(res["gap_candidates"]) | changed
    names = resolve_names(targets)
    rows = []
    for cid in res["gap_candidates"]:
        b = prev_by.get(cid, {})
        det = detail_of(b.get("id"))
        rows.append({
            "customer_id": cid, "period_ym": ym, "company_name": names.get(cid, ""),
            "verdict": "発行漏れ候補", "product_name": det["product_name"],
            "prev_amount": res["prev_amount"].get(cid), "curr_amount": None,
            "issue_date": b.get("issue_date"), "updated_at": det["updated_at"],
        })
    for cid in res["continuing"]:
        if cid not in changed:
            continue
        b = curr_by.get(cid, {})
        det = detail_of(b.get("id"))
        rows.append({
            "customer_id": cid, "period_ym": ym, "company_name": names.get(cid, ""),
            "verdict": "継続発行", "product_name": det["product_name"],
            "prev_amount": res["prev_amount"].get(cid), "curr_amount": res["curr_amount"].get(cid),
            "issue_date": b.get("issue_date"), "updated_at": det["updated_at"],
        })
    return res, rows


def _print_summary(ym, res, rows):
    print(f"== 発行漏れチェック {prev_month(ym)} → {ym} ==")
    print(f"発行漏れ候補: {len(res['gap_candidates'])}件 / "
          f"継続発行: {len(res['continuing'])}件 / 今月新規: {len(res['new_this_month'])}件")
    for r in rows:
        amt = f"前月{r['prev_amount']}→今月{r['curr_amount']}"
        print(f"  [{r['verdict']}] {r['company_name']}({r['customer_id']}) {r['product_name']} {amt}")


def main():
    p = argparse.ArgumentParser(description="MF掛け払い 月次発行漏れチェック")
    p.add_argument("--collect", action="store_true")
    p.add_argument("--sink", action="store_true")
    p.add_argument("--month", help="対象月 YYYY-MM (既定: 実行日の月)")
    p.add_argument("--input", help="sink入力の候補JSON (既定: eval-log/mfk-gap-candidates.json)")
    p.add_argument("--out", help="collect出力先 (既定: eval-log/mfk-gap-candidates.json)")
    a = p.parse_args()

    if a.sink:
        path = a.input or DEFAULT_CANDIDATES
        with open(path, encoding="utf-8") as f:
            rows = json.load(f)
        cfg = load_config()
        db_id = (cfg.get("notion") or {}).get("database_id")
        if not db_id:
            sys.stderr.write("[check] notion.database_id 未設定。先に run-mf-invoice-db-setup を実行してください。\n")
            return 2
        r = notion_invoice_sink.upsert(db_id, rows)
        print(f"Notion upsert: created={r['created']} updated={r['updated']}")
        return 0

    # 既定は collect
    ym = a.month or datetime.date.today().strftime("%Y-%m")
    res, rows = collect(ym)
    _print_summary(ym, res, rows)
    out = a.out or DEFAULT_CANDIDATES
    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out, "w", encoding="utf-8") as f:
        json.dump(rows, f, ensure_ascii=False, indent=2)
        f.write("\n")
    print(f"\n候補を {out} に出力 ({len(rows)}件)。subagent検証後に --sink で Notion 投入してください。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
